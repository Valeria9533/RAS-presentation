#include <webots/DistanceSensor.hpp>
#include <webots/Motor.hpp>
#include <webots/Robot.hpp>
#include <webots/Keyboard.hpp>

#define TIME_STEP 64
using namespace webots;

int main(int argc, char **argv) {
  Robot *robot = new Robot(); // allocate dynamic memory
  Keyboard kb;
  DistanceSensor *ds[2];
  
  char dsNames[2][10] = {"ds_left", "ds_right"};
  for (int i = 0; i < 2; i++) {
    ds[i] = robot->getDistanceSensor(dsNames[i]);
    ds[i]->enable(TIME_STEP);
  }
  
  Motor *wheels[4];
  char wheels_names[4][8] = {"wheel_1", "wheel_2", "wheel_3", "wheel_4"};
  for (int i = 0; i < 4; i++) {
    wheels[i] = robot->getMotor(wheels_names[i]);
    wheels[i]->setPosition(INFINITY);
    wheels[i]->setVelocity(0.0);
  }
  
  kb.enable(TIME_STEP);
  double leftSpeed = 0.0;
  double rightSpeed = 0.0;
  while (robot->step(TIME_STEP) != -1) {
    int key=kb.getKey();
    
    if (key==315){ // top arrow is pressed 
    leftSpeed = 5.0;
    rightSpeed = 5.0;
    } else if (key==317){ // bottom arrow is pressed 
    leftSpeed = -5.0;
    rightSpeed = -5.0;
    }else if (key==316){ // right arrow is pressed 
    leftSpeed = 5.0;
    rightSpeed = -5.0;
    }else if (key==314){ // left arrow is pressed 
    leftSpeed = -5.0;
    rightSpeed = 5.0;
    }else {
    leftSpeed = 0.0;
    rightSpeed = 0.0;
    }
   
   // get values from sensors
    std::cout<<ds[0]->getValue()<<"=Right Sensor"<<std::endl;
    std::cout<<ds[1]->getValue()<<"=Left Sensor"<<std::endl;
   
    wheels[0]->setVelocity(leftSpeed);
    wheels[1]->setVelocity(rightSpeed);
    wheels[2]->setVelocity(leftSpeed);
    wheels[3]->setVelocity(rightSpeed);
   
  }
  delete robot; // clear memory (as it was dynamically allocated)
  return 0;  // EXIT_SUCCESS
}