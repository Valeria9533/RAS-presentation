// add the include directives corresponding to the Robot, 
// the DistanceSensor and the Motor nodes in order to be 
// able to use the corresponding API
#include <webots/DistanceSensor.hpp>
#include <webots/Motor.hpp>
#include <webots/Robot.hpp>

// duration of each physics step
#define TIME_STEP 64

// use the Webots namespace which is required to use the Webots classes
using namespace webots;

int main(int argc, char **argv) {

  // create the Robot instance (allocate dynamic memory)
  Robot *robot = new Robot();
  
  // initialize devices
  DistanceSensor *ds[2];
  char dsNames[2][10] = {"ds_right", "ds_left"};                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
  for (int i = 0; i < 2; i++) {
    ds[i] = robot->getDistanceSensor(dsNames[i]);
    ds[i]->enable(TIME_STEP); // every 64 ms we get data 
                              // from sensors
  }
  
  // initialize motors
  Motor *wheels[4];
  char wheels_names[4][8] = {"wheel_1", "wheel_2", "wheel_3", "wheel_4"};
  for (int i = 0; i < 4; i++) {
    wheels[i] = robot->getMotor(wheels_names[i]);
    wheels[i]->setPosition(INFINITY);
    wheels[i]->setVelocity(0.0);
  }
  
  // feedback loop: step simulation until receiving an exit event
  while (robot->step(TIME_STEP) != -1) {
  
    double leftSpeed;
    double rightSpeed;
    
    std::cout<<ds[0]->getValue()<<"=Right Sensor"<<std::endl;
    std::cout<<ds[1]->getValue()<<"=Left Sensor"<<std::endl;
    
    for (int i = 0; i < 2; i++) {
        if (ds[i]->getValue() < 950.0)
          {
            leftSpeed = 2.0; // turn right
            rightSpeed = -2.0;
          }
        else
        {
          leftSpeed = 2.0; // go forward
          rightSpeed = 2.0;
        }
      }
    
    wheels[0]->setVelocity(leftSpeed);
    wheels[1]->setVelocity(rightSpeed);
    wheels[2]->setVelocity(leftSpeed);
    wheels[3]->setVelocity(rightSpeed);
  }
  
  // clean up memory
  delete robot;
  return 0;  // EXIT_SUCCESS
}
